=== Location Weather ===
Contributors: andrew_gikavchuk
Tags: weather, weather widget, wordpress weather plugin, open weather, nice weather, current conditions, forecast, travel, celsius, fahrenheit, clouds, Geo-Location, plugin, widget, wordpress, cloud, cloudiness, global, yahoo, conditions, current weather, dew, ephemeris, forecast widget, frost, gauge, ajax weather widget, ajax weather, simple weather, weather forecast, get weather
Requires at least: 4.0
Tested up to: 5.0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Location Weather is a flexible and easy to use weather plugin that allows you to add unlimited weather widgets and get up-to-date weather information to your site or sidebar.

== Description ==


Simple Weather is a flexible and easy to use weather plugin that allows you to add unlimited weather widgets and get up-to-date weather information to your site or sidebar.

Create a weather, set your city and country, choose the options and customize the look in a few clicks.

= FEATURES =

* Fully responsive.
* Minimalist & lightweight.
* Super easy to use.
* Set widget title.
* Real-time weather forecasts.
* Set default location: city and country.
* All major browsers supported.
* Compatible with any theme.

== Installation ==

Installing this plugin as regular WordPress plugin.

After install, you are ready to use Location Weather in your widget. How to create Location Weather? lets
see.


1. Upload the folder open-weather to "/wp-content/plugins/" '
2. Activate the plugin through the "Plugins" menu in WordPress .
3. Add Location Weather in your widget .



== Screenshots ==

1. Widget


== Changelog ==

= 1.0 =
* First Release




